import * as React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import EmpDetails from "./EmpDetails";
import EmployeeTable from './EmployeeTable';
export const AppRouter: React.StatelessComponent<{}> = () => {
    return (

        <Router>
            <div>
                <Route exact={true} path="/" component={EmployeeTable} />
                <Route path="/get/:id" component={EmpDetails} />
            </div>
        </Router>
    );
}
